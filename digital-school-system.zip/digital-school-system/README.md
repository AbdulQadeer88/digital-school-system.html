# Digital School System

A role-based school management web app built with HTML, CSS and JavaScript.

## Features
- Admin: add/remove students, dashboard, fee payments
- Teacher: daily attendance by class and date, enter/delete marks
- Student: view own attendance, results and fee due

## Demo logins
| Role | Username | Password |
|------|----------|----------|
| Admin | admin | admin123 |
| Teacher | teacher | teacher123 |
| Student | s1 to s4 | student123 |

## Project structure
- index.html - page structure
- style.css - styling and dark mode
- app.js - data, login, screens and events (uses browser localStorage)

## Run
Open index.html in a browser. No installation needed.
