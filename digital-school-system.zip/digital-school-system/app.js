var mem={};
function load(k,d){try{var v=localStorage.getItem(k);if(v)return JSON.parse(v)}catch(e){}return mem[k]!==undefined?mem[k]:d}
function save(k,v){mem[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
var seed=[["Ayesha Khan","8",1],["Bilal Ahmed","8",2],["Hina Malik","9",1],["Usman Ali","9",2]];
var students=load("dss_students",seed.map(function(s,i){return{id:"s"+(i+1),name:s[0],cls:s[1],roll:s[2],total:15000,paid:i%2?7500:15000}}));
var attendance=load("dss_att",{});
var marks=load("dss_marks",[{sid:"s1",subject:"Math",score:88,total:100},{sid:"s1",subject:"English",score:76,total:100},{sid:"s2",subject:"Math",score:64,total:100}]);
var user=null,tab="",today=new Date().toISOString().slice(0,10),attDate=today,attClass="8";
function $(h){return h}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function persist(){save("dss_students",students);save("dss_att",attendance);save("dss_marks",marks)}
function toast(m){var t=document.createElement("div");t.className="toast";t.textContent=m;document.body.appendChild(t);setTimeout(function(){t.remove()},1800)}
function pct(sid){var d=0,p=0;for(var k in attendance){if(attendance[k][sid]){d++;if(attendance[k][sid]==="P")p++}}return d?Math.round(p/d*100):null}
function login(e){var u=document.getElementById("u").value.trim().toLowerCase(),p=document.getElementById("p").value;
 if(u==="admin"&&p==="admin123")user={role:"admin",name:"Administrator"};
 else if(u==="teacher"&&p==="teacher123")user={role:"teacher",name:"Teacher"};
 else{var s=students.filter(function(x){return x.id===u})[0];if(s&&p==="student123")user={role:"student",name:s.name,sid:s.id}}
 if(!user){toast("Wrong username or password");return}
 tab=user.role==="admin"?"Dashboard":user.role==="teacher"?"Attendance":"My Record";render()}
function logout(){user=null;render()}
function tabs(){return user.role==="admin"?["Dashboard","Students","Fees"]:user.role==="teacher"?["Attendance","Marks"]:["My Record"]}
function render(){var a=document.getElementById("app");
 if(!user){a.innerHTML='<div class="login"><div class="panel"><h1>Digital School System</h1><p class="muted ui">Sign in to continue.</p><div class="row"><label>Username<input id="u" autocomplete="username"></label></div><div class="row"><label>Password<input id="p" type="password" autocomplete="current-password"></label></div><button class="primary" id="go">Sign in</button><p class="hint">Demo accounts: admin / admin123, teacher / teacher123, student s1 / student123 (s1 to s4).</p></div></div>';
  document.getElementById("go").onclick=login;document.getElementById("p").onkeydown=function(e){if(e.key==="Enter")login()};return}
 var h='<header class="top"><h1>Digital School System</h1><div class="ui"><span class="muted">'+esc(user.name)+' ('+user.role+')</span> <button id="out">Sign out</button></div></header><nav>';
 tabs().forEach(function(t){h+='<button data-t="'+t+'" class="'+(t===tab?"on":"")+'">'+t+'</button>'});
 h+='</nav><div id="view"></div>';a.innerHTML=h;
 a.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){tab=b.dataset.t;render()}});
 document.getElementById("out").onclick=logout;
 var v=document.getElementById("view");v.innerHTML=({Dashboard:vDash,Students:vStu,Fees:vFees,Attendance:vAtt,Marks:vMarks,"My Record":vMine})[tab]();
 bind(v)}
function vDash(){var due=0,ps=0,n=0;students.forEach(function(s){due+=s.total-s.paid;var p=pct(s.id);if(p!==null){ps+=p;n++}});
 return '<div class="stats"><div class="stat"><b>'+students.length+'</b><span>Students</span></div><div class="stat"><b>'+(n?Math.round(ps/n)+"%":"-")+'</b><span>Average attendance</span></div><div class="stat"><b>'+due.toLocaleString()+'</b><span>Fees due (PKR)</span></div><div class="stat"><b>'+marks.length+'</b><span>Marks entries</span></div></div><div class="panel"><h3>Welcome</h3><p>Use Students to add or remove pupils, and Fees to record payments. Teachers mark attendance and enter marks; students see their own record.</p></div>'}
function vStu(){var r='<div class="panel"><h3>Add student</h3><div class="row"><label>Name<input id="n"></label><label>Class<input id="c" size="4"></label><label>Roll no.<input id="r" type="number" size="4"></label><label>Annual fee<input id="f" type="number" value="15000"></label><button class="primary" id="add">Add student</button></div></div><div class="panel tbl"><table><tr><th>ID</th><th>Name</th><th>Class</th><th>Roll</th><th></th></tr>';
 students.forEach(function(s){r+='<tr><td>'+s.id+'</td><td>'+esc(s.name)+'</td><td>'+esc(s.cls)+'</td><td>'+s.roll+'</td><td><button class="danger" data-del="'+s.id+'">Remove</button></td></tr>'});
 return r+'</table></div>'}
function vFees(){var r='<div class="panel tbl"><table><tr><th>Student</th><th>Total</th><th>Paid</th><th>Due</th><th>Record payment</th></tr>';
 students.forEach(function(s){var d=s.total-s.paid;r+='<tr><td>'+esc(s.name)+'</td><td>'+s.total+'</td><td>'+s.paid+'</td><td class="'+(d?"bad":"ok")+'">'+d+'</td><td><input type="number" min="0" size="6" id="pay_'+s.id+'" placeholder="Amount"> <button data-pay="'+s.id+'">Save</button></td></tr>'});
 return r+'</table></div>'}
function classes(){var c=[];students.forEach(function(s){if(c.indexOf(s.cls)<0)c.push(s.cls)});return c}
function vAtt(){var cl=classes();if(cl.indexOf(attClass)<0)attClass=cl[0]||"";var day=attendance[attDate]||{};
 var r='<div class="panel"><div class="row"><label>Date<input type="date" id="ad" value="'+attDate+'"></label><label>Class<select id="ac">'+cl.map(function(c){return'<option'+(c===attClass?" selected":"")+'>'+esc(c)+'</option>'}).join("")+'</select></label></div><div class="tbl"><table><tr><th>Roll</th><th>Name</th><th>Present</th></tr>';
 students.filter(function(s){return s.cls===attClass}).forEach(function(s){r+='<tr><td>'+s.roll+'</td><td>'+esc(s.name)+'</td><td><input type="checkbox" data-att="'+s.id+'"'+(day[s.id]!=="A"?" checked":"")+'></td></tr>'});
 return r+'</table></div><p><button class="primary" id="sa">Save attendance</button></p></div>'}
function vMarks(){var o=students.map(function(s){return'<option value="'+s.id+'">'+esc(s.name)+'</option>'}).join("");
 var r='<div class="panel"><h3>Enter marks</h3><div class="row"><label>Student<select id="ms">'+o+'</select></label><label>Subject<input id="sub"></label><label>Score<input id="sc" type="number" min="0" size="4"></label><label>Out of<input id="tt" type="number" value="100" size="4"></label><button class="primary" id="am">Save marks</button></div></div><div class="panel tbl"><table><tr><th>Student</th><th>Subject</th><th>Score</th><th></th></tr>';
 marks.forEach(function(m,i){var s=students.filter(function(x){return x.id===m.sid})[0];r+='<tr><td>'+(s?esc(s.name):m.sid)+'</td><td>'+esc(m.subject)+'</td><td>'+m.score+'/'+m.total+'</td><td><button class="danger" data-dm="'+i+'">Delete</button></td></tr>'});
 return r+'</table></div>'}
function vMine(){var s=students.filter(function(x){return x.id===user.sid})[0];if(!s)return"<p>No record found.</p>";var p=pct(s.id),d=s.total-s.paid;
 var r='<div class="stats"><div class="stat"><b>'+(p===null?"-":p+"%")+'</b><span>Attendance</span></div><div class="stat"><b>'+s.cls+'</b><span>Class</span></div><div class="stat"><b class="'+(d?"bad":"ok")+'">'+d+'</b><span>Fee due (PKR)</span></div></div><div class="panel tbl"><h3>My results</h3><table><tr><th>Subject</th><th>Score</th><th>Percent</th></tr>';
 var mine=marks.filter(function(m){return m.sid===s.id});
 if(!mine.length)r+='<tr><td colspan="3" class="muted">No marks entered yet.</td></tr>';
 mine.forEach(function(m){r+='<tr><td>'+esc(m.subject)+'</td><td>'+m.score+'/'+m.total+'</td><td>'+Math.round(m.score/m.total*100)+'%</td></tr>'});
 return r+'</table></div>'}
function bind(v){var q=function(i){return v.querySelector(i)};
 if(q("#add"))q("#add").onclick=function(){var n=q("#n").value.trim(),c=q("#c").value.trim(),r=+q("#r").value,f=+q("#f").value;if(!n||!c||!r){toast("Enter name, class and roll number");return}
  var id=1;students.forEach(function(s){id=Math.max(id,+s.id.slice(1)+1)});students.push({id:"s"+id,name:n,cls:c,roll:r,total:f||0,paid:0});persist();toast("Student added");render()};
 v.querySelectorAll("[data-del]").forEach(function(b){b.onclick=function(){var id=b.dataset.del;students=students.filter(function(s){return s.id!==id});marks=marks.filter(function(m){return m.sid!==id});persist();toast("Student removed");render()}});
 v.querySelectorAll("[data-pay]").forEach(function(b){b.onclick=function(){var id=b.dataset.pay,a=+document.getElementById("pay_"+id).value;if(!(a>0)){toast("Enter an amount");return}
  students.forEach(function(s){if(s.id===id)s.paid=Math.min(s.total,s.paid+a)});persist();toast("Payment saved");render()}});
 if(q("#ad"))q("#ad").onchange=function(){attDate=this.value||today;render()};
 if(q("#ac"))q("#ac").onchange=function(){attClass=this.value;render()};
 if(q("#sa"))q("#sa").onclick=function(){var day=attendance[attDate]||{};v.querySelectorAll("[data-att]").forEach(function(c){day[c.dataset.att]=c.checked?"P":"A"});attendance[attDate]=day;persist();toast("Attendance saved")};
 if(q("#am"))q("#am").onclick=function(){var sub=q("#sub").value.trim(),sc=+q("#sc").value,tt=+q("#tt").value;if(!sub||q("#sc").value===""||!tt||sc>tt){toast("Check subject and score");return}
  marks.push({sid:q("#ms").value,subject:sub,score:sc,total:tt});persist();toast("Marks saved");render()};
 v.querySelectorAll("[data-dm]").forEach(function(b){b.onclick=function(){marks.splice(+b.dataset.dm,1);persist();render()}})}
render();
